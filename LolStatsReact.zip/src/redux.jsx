
const initalState = {
  highlightedPlayer: {},
  players: {}
}

function LoLapp (state = initalState, action) {
  switch (action.type) {
    case expression:

      break;
    default:
      return state
  }
}
module.exports = LoLapp
